package com.cts;

public class MyServiceClass {

	public void display(String message) {
		System.out.println(message);
	}
}
