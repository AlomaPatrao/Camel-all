package com.cts;

public class MyCustomBean {

	public void display(String message) {
		System.out.println("Hello From Bean! " + message);
	}
}
