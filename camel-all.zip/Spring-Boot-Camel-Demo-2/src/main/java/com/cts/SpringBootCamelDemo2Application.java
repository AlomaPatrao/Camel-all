package com.cts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCamelDemo2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCamelDemo2Application.class, args);
	}

}
